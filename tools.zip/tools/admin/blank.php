<?php  require_once('parts/top.php');?>
    </head>
    <body class="sb-nav-fixed">
       
	   <?php  require_once('parts/navbar.php');?>
	   
        <div id="layoutSidenav">
           
	<?php  require_once('parts/sidebar.php');?>
	
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-3">User</h1>
						
						
						
						
						
                          
                </main>
               
			    <?php  require_once('parts/footer.php');?>
			   
            </div>
			   
        </div>
        <!--Footercdn--->
			<?php require_once('parts/footercdn.php');?>

    </body>
</html>
