      <?php     
	  
		$conn = mysqli_connect ('localhost','root','','toolsdb');	
	//	if(mysqli_connect_errno()){
		//	echo "failed";
		//}else{
		//	echo "connection ok";
		//}
			?>